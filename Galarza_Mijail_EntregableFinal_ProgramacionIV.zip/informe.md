# TechStore
## Informe Técnico del Proyecto — Programación 4

**Aplicación web de inventario de computadoras y periféricos con CRUD e inteligencia artificial local (Ollama)**

---

## 1. Descripción general

**TechStore** es una aplicación web desarrollada con **Django** que administra el
inventario de una tienda dedicada exclusivamente a **computadoras y periféricos de
computadoras**. El sistema permite:

- Registrar, consultar, editar y desactivar productos (**CRUD**).
- Buscar productos por código, nombre o categoría.
- Controlar existencias: aumentar, disminuir, consultar agotados y stock bajo.
- Generar **8 reportes predefinidos** sobre el inventario.
- Conversar con un **chat de inteligencia artificial local (Ollama)** que responde
  únicamente con los datos reales registrados.

El proyecto no incluye ventas, compras, facturación, usuarios avanzados ni servicios
de IA en la nube, según el alcance definido en el requerimiento.

---

## 2. Objetivo

Implementar una aplicación Django que integre el registro y administración de
productos de una tienda de computación, control de existencias, reportes y un chat
respondido por un modelo de IA local (Ollama), cuyas respuestas estén restringidas
exclusivamente a la información almacenada en el inventario.

---

## 3. Alcance del sistema

El sistema se compone de dos módulos:

| Módulo | Descripción |
| --- | --- |
| **Módulo de productos** | CRUD completo del inventario + control de existencias + búsquedas + reportes. |
| **Módulo de inteligencia artificial** | Chat en lenguaje natural, reportes predefinidos y respuestas generadas por Ollama a partir de los datos registrados. |

---

## 4. Requerimientos funcionales implementados

| Código | Requerimiento | Estado |
| --- | --- | --- |
| **RF-01** | Registro de productos con validaciones (código único, campos obligatorios). | Implementado |
| **RF-02** | Consulta de productos con búsqueda por código, nombre y categoría. | Implementado |
| **RF-03** | Actualización de productos (existe, código único, precios/cantidades no negativas). | Implementado |
| **RF-04** | Eliminación lógica: el producto pasa a estado *inactivo* y conserva su historial. | Implementado |
| **RF-05** | Control de existencia: registrar, aumentar, disminuir, agotados, stock bajo, sin negativos. | Implementado |
| **RF-06** | Menú de reportes predefinidos con opción de explicación con IA. | Implementado |
| **RF-07** | Chat con IA en lenguaje natural. | Implementado |
| **RF-08** | Integración con Ollama mediante API local (`http://localhost:11434`). | Implementado |
| **RF-09** | Restricción de respuestas: la IA solo usa datos del inventario. | Implementado |
| **RF-10** | Historial de consultas (pregunta, respuesta, fecha). | Implementado |

---

## 5. Modelo de datos

### 5.1 Entidad Producto (`inventario`)

| Campo | Tipo | Descripción | Restricción |
| --- | --- | --- | --- |
| `id` | Entero | Identificador automático | PK |
| `codigo` | Texto (20) | Código único del producto | Único |
| `nombre` | Texto (120) | Nombre del producto | Obligatorio |
| `descripcion` | Texto | Descripción general | Opcional |
| `categoria` | Texto (30) | `Computadoras` \| `Periféricos` | Opción definida |
| `precio` | Decimal (10,2) | Precio del producto | Mayor e igual a 0 |
| `cantidad_existente` | Entero positivo | Cantidad disponible | Mayor e igual a 0 |
| `stock_minimo` | Entero positivo | Nivel mínimo permitido | Mayor e igual a 0 |
| `estado` | Booleano | Activo o inactivo | Default `True` |
| `fecha_registro` | Fecha y hora | Fecha de creación | Automática |

Propiepiades calculadas: `agotado` (existencia = 0), `stock_bajo`
(existencia menor o igual al mínimo) y `valor_total` (precio × cantidad).

### 5.2 Entidad ConsultaIA (`asistente`)

| Campo | Tipo | Descripción |
| --- | --- | --- |
| `id` | Entero | Identificador de la consulta |
| `pregunta` | Texto | Pregunta escrita por el usuario |
| `respuesta` | Texto | Respuesta generada por Ollama |
| `fecha` | Fecha y hora | Fecha de la consulta (automática) |

---

## 6. Arquitectura

```text
Usuario
   │
   ▼
Interfaz web Django
   │
   ├── CRUD de productos ──────► Base de datos (SQLite)
   │
   └── Consultas de IA
           │
           ▼
      Backend Django (servicio asistente)
           │
           ▼
          Ollama  (http://localhost:11434)
           │
           ▼
       Modelo local
```

La comunicación con Ollama se realiza desde el backend de Django mediante su API
local: `http://localhost:11434/api/generate`.

---

## 7. Estructura del proyecto

```text
TechStore/
├── manage.py
├── requirements.txt
├── .env.example
├── Modelfile
├── README.md
├── Informe_Proyecto_TechStore.md      (este documento)
├── config/                            # proyecto Django
│   ├── settings.py                    # configuración + variables de Ollama
│   └── urls.py
├── inventario/                        # app CRUD de productos
│   ├── models.py                      # entidad Producto
│   ├── forms.py                       # validaciones (código único, no negativos)
│   ├── views.py                       # CRUD, stock, búsqueda y reportes
│   ├── admin.py
│   ├── urls.py
│   ├── management/commands/seed_productos.py   # datos de ejemplo
│   └── templates/inventario/…         # plantillas HTML
├── asistente/                         # app de inteligencia artificial
│   ├── models.py                      # entidad ConsultaIA
│   ├── services.py                    # integración con Ollama
│   ├── views.py                       # chat, explicación y historial
│   ├── forms.py
│   ├── urls.py
│   └── templates/asistente/…          # plantillas HTML
└── templates/base.html                # plantilla base (Bootstrap)
```

---

## 8. Instalación y ejecución

### 8.1 Requisitos

- Python 3.10 o superior.
- [Ollama](https://ollama.com) instalado y ejecutándose localmente.
- Modelo descargado, por ejemplo: `ollama pull qwen2.5:1.5b`.

### 8.2 Pasos

```bash
# 1. Crear el entorno virtual e instalar dependencias
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# 2. Configurar variables de entorno (opcional)
cp .env.example .env

# 3. Aplicar migraciones y cargar datos de ejemplo
python manage.py migrate
python manage.py seed_productos

# 4. Ejecutar el servidor de desarrollo
python manage.py runserver
```

Abrir en el navegador: **http://127.0.0.1:8000/**

### 8.3 Contenido de `.env` (variables de configuración)

| Variable | Valor por defecto | Descripción |
| --- | --- | --- |
| `OLLAMA_URL` | `http://localhost:11434/api/generate` | API de generación de Ollama |
| `OLLAMA_MODEL` | `qwen2.5:1.5b` | Modelo local de Ollama |
| `OLLAMA_TIMEOUT` | `60` | Segundos máximos de espera |

---

## 9. Descripción funcional del CRUD

A continuación se describe el comportamiento funcional de cada operación del
CRUD, sin incluir fragmentos de código de vistas ni de formularios.

### 9.1 Registrar producto (RF-01)

El sistema presenta un formulario con los campos del producto (código, nombre,
descripción, categoría, precio, cantidad existente y stock mínimo) y valida los
datos antes de guardarlos. Las reglas de validación son:

- **Código único**: no se admite un código ya registrado.
- **Precio**: debe ser mayor o igual que 0.
- **Cantidad existente y stock mínimo**: deben ser mayores o iguales que 0.
- **Campos obligatorios**: código, nombre, categoría y precio.

Si los datos son válidos se muestra un mensaje de éxito; en caso contrario se
informa el error y se conserva lo ingresado.

### 9.2 Consultar y buscar productos (RF-02)

El sistema muestra el listado de productos activos con código, nombre,
categoría, precio, cantidad disponible, stock mínimo y estado. Además permite
filtrar:

- Por cualquier texto, que debe coincidir con el **código** o el **nombre**.
- Por **categoría**: Computadoras o Periféricos.

### 9.3 Actualizar producto (RF-03)

El sistema permite modificar los datos de un producto existente. Al guardar se
valida que el producto exista, que el código no se repita con otro producto, que
el precio no sea negativo y que las cantidades no sean negativas.

### 9.4 Eliminar producto (RF-04) — eliminación lógica

En lugar de borrar el registro definitivamente, el sistema cambia el estado del
producto a *inactivo*. El producto desaparece del listado principal pero se
conserva en el historial y puede **reactivarse** desde la sección de productos
inactivos.

### 9.5 Control de existencia (RF-05)

El sistema permite **aumentar** o **disminuir** la cantidad disponible de cada
producto, y la disminución no puede dejar la existencia en un valor negativo
(se valida que la cantidad a restar no supere la disponible). También ofrece
consultas dedicadas para los productos **agotados** (existencia igual a 0) y los
productos con **stock bajo** (existencia menor o igual al stock mínimo).

---

## 10. Reportes predefinidos (RF-06)

| # | Reporte | Ruta |
| --- | --- | --- |
| 1 | Listar todos los productos | `/productos/` |
| 2 | Producto más caro | `/productos/reportes/mas-caro/` |
| 3 | Producto más barato | `/productos/reportes/mas-barato/` |
| 4 | Productos con pocas existencias | `/productos/stock/bajo/` |
| 5 | Productos agotados | `/productos/stock/agotados/` |
| 6 | Productos por categoría | `/productos/reportes/por-categoria/` |
| 7 | Valor total del inventario | `/productos/reportes/valor-inventario/` |
| 8 | Productos con mayor cantidad | `/productos/reportes/mayor-existencia/` |

Cada reporte puede presentarse **directamente al usuario** o enviarse a Ollama
mediante el botón **"Explicar con IA"**, que formula la pregunta correspondiente
y obtiene del asistente una explicación en lenguaje natural sobre los datos del
reporte.

---

## 11. Integración con inteligencia artificial (RF-07, RF-08 y RF-09)

### 11.1 Flujo de la consulta

1. El usuario escribe una pregunta en el chat o usa *Explicar con IA*.
2. Django recibe la consulta.
3. Django obtiene los productos **activos** de la base de datos.
4. Django transforma los datos a JSON estructurado (código, nombre, categoría,
   precio, cantidad, stock mínimo).
5. Django calcula datos clave (producto más caro/barato, valor total, agotados,
   stock bajo, conteo por categoría).
6. Django construye el contexto y lo envía a Ollama.
7. Ollama procesa y devuelve la respuesta en lenguaje natural.
8. Django guarda la consulta en `ConsultaIA` y la muestra al usuario.

### 11.2 Contexto enviado a Ollama

El prompt combina tres secciones:

```text
Eres el asistente encargado de consultar el inventario de TechStore, una tienda
de computadoras y periféricos de computadoras.

Responde ÚNICAMENTE utilizando los datos incluidos en INVENTARIO y en DATOS CLAVE.
No inventes productos, precios ni cantidades.
DATOS CLAVE son cálculos realizados por el sistema y deben considerarse correctos.
Si la información no está disponible o la pregunta no guarda relación con las
computadoras o periféricos registrados, responde exactamente:
"No encontré información suficiente en el inventario para responder esa pregunta."

DATOS CLAVE:
{datos_clave}

INVENTARIO:
{inventario}

PREGUNTA DEL USUARIO:
{pregunta}
```

**Datos clave**: para que el modelo local responda con exactitud, Django
precalcula el valor total del inventario, el producto más caro y más barato,
los agotados, los de stock bajo y los conteos por categoría. Estos hechos se
incluyen en el contexto y la IA debe considerarlos correctos.

### 11.3 Restricción de respuestas (RF-09)

- El modelo responde **exclusivamente** con la información del inventario.
- Si la pregunta no trata sobre computadoras/periféricos registrados o no hay
  datos suficientes, responde el mensaje definido:
  > No encontré información suficiente en el inventario para responder esa pregunta.
- Está prohibido inventar productos, precios o cantidades.

### 11.4 Disponibilidad de Ollama

Si Ollama no está disponible (servicio detenido, timeout o error HTTP), el
sistema muestra un **mensaje de error claro** sin interrumpir el resto de la
aplicación. Se controlan los casos de *ConnectionError*, *Timeout* y *HTTPError*
al comunicarse con el servidor local.

### 11.5 Historial de consultas (RF-10)

Cada intercambio en el chat se guarda en el historial (pregunta, respuesta y
fecha) y puede revisarse desde la página de historial de consultas.

### 11.6 Modelo personalizado con Modelfile

El proyecto incluye un **Modelfile** que crea el modelo `techstore` a partir de
`qwen2.5:1.5b`, con temperatura 0 y un prompt de sistema que refuerza las
restricciones del RF-09 y el contexto del CRUD:

```bash
ollama create techstore -f Modelfile
```

Para usarlo: `OLLAMA_MODEL=techstore` en `.env`.

---

## 12. Criterios de aceptación verificados

Se comprobó mediante pruebas reales (cliente de pruebas y consultas directas a Ollama):

| Criterio | Resultado |
| --- | --- |
| Crear un producto | ✔ Registrado correctamente |
| Consultar la lista de productos | ✔ Listado con búsqueda |
| Editar un producto | ✔ Actualización correcta |
| Eliminar/desactivar un producto | ✔ Estado cambia a inactivo; reactivable |
| Validar código único | ✔ Duplicado rechazado |
| No permitir precios/cantidades negativos | ✔ Rechazado |
| Consultar por nombre o categoría | ✔ Filtros aplican |
| Identificar producto más caro | ✔ Lenovo Legion ($1,350.00) |
| Identificar producto más barato | ✔ Audífonos ($22.00) |
| Consultar productos con pocas existencias | ✔ Listado de stock bajo |
| Consultar el valor total del inventario | ✔ $12,777.50 |
| Realizar preguntas desde el chat | ✔ Chat funcional |
| Enviar datos a Ollama | ✔ Conexión local exitosa |
| Respuestas usando productos registrados | ✔ Respuestas con datos reales |
| Informar cuando Ollama no esté disponible | ✔ Mensaje de error controlado |
| No inventar información inexistente | ✔ Preguntas ajenas rechazadas |
| Instrucciones de instalación y ejecución | ✔ Ver sección 8 |

---

## 13. Entregables

1. Código fuente del proyecto Django. ✔
2. Aplicación CRUD de productos. ✔
3. Integración funcional con Ollama. ✔
4. Menú de reportes predefinidos. ✔
5. Chat para consultas sobre el inventario. ✔
6. Modelo de base de datos (SQLite). ✔
7. Archivo `requirements.txt`. ✔
8. Archivo `.env.example`. ✔
9. Documento con instrucciones de instalación (README e informe). ✔
10. Evidencias de funcionamiento (pruebas de CRUD, reportes y chat con Ollama). ✔
11. Modelfile para el modelo local de IA. ✔

---

## 14. Conclusiones

- El proyecto cumple los requerimientos funcionales y no funcionales del
  entregable: CRUD completo, control de existencias, búsquedas, reportes y
  chat con IA local.
- La integración con Ollama funciona de extremo a extremo: Django construye el
  contexto a partir de la base de datos, lo envía al modelo local y muestra la
  respuesta, restringiendo los temas a computadoras y periféricos.
- El pre-cálculo de **datos clave** en Django garantiza que el modelo responda
  con exactitud, sin inventar información.
- La aplicación es robusta ante la ausencia de Ollama, mostrando mensajes de
  error claros.

---

## 15. Herramientas y asistentes de desarrollo

### 15.1 Herramientas principales

| Herramienta | Uso en el proyecto |
| --- | --- |
| **Python + Django 5** | Framework web: aplicaciones `inventario` y `asistente`, ORM, plantillas y admin. |
| **SQLite** | Base de datos local, sin configuración adicional. |
| **Bootstrap 5** | Interfaz web responsive (CSS + componentes). |
| **Ollama** | Servidor local de IA; modelo `qwen2.5:1.5b` y modelo personalizado `techstore`. |
| **Markdown + xhtml2pdf** | Generación del informe técnico en PDF. |

### 15.2 Asistencia con IA en el desarrollo (opencode)

El desarrollo del proyecto se realizó con el apoyo del **asistente de
programación opencode** (asistente de IA integrado en la terminal). Su uso fue
crucial en las siguientes tareas:

- **Análisis y diseño**: estructura de las aplicaciones Django (`inventario` y
  `asistente`), entidades `Producto` y `ConsultaIA`, y arquitectura de
  comunicación con Ollama.
- **Implementación del CRUD**: código de modelos, formularios, vistas,
  rutas y plantillas, incluidas las validaciones de código único y valores no
  negativos.
- **Lógica de negocio**: control de existencias (aumentar/disminuir sin valores
  negativos), búsquedas, los 8 reportes predefinidos y el cálculo de datos
  clave para la IA.
- **Integración con Ollama**: servicio de conexión a la API local, manejo de
  errores (conexión, timeout, HTTP) y construcción del contexto restringido para
  las respuestas.
- **Generación del Modelfile** y del modelo personalizado `techstore`.
- **Verificación y pruebas**: uso del cliente de pruebas de Django para validar
  el CRUD, valores de ejemplo, cifras de inventario y las respuestas del chat.
- **Scripts de utilidad**: comandos para poblar la base de datos, convertir el
  informe a PDF y generar el archivo ZIP del entregable.
- **Documentación**: redacción y revisión del presente informe, del README y
  del resto de la documentación del proyecto.

Todas las decisiones técnicas fueron revisadas y aprobadas por el autor; el
asistente actuó como copiloto en la escritura de código, la depuración y la
documentación.

---

## 16. Referencias

Django Software Foundation. (2026). *Django documentation* [Documentación en
línea]. https://docs.djangoproject.com/

Ollama. (2025). *Ollama: Get up and running with large language models locally*
[Documentación en línea]. https://ollama.com/

American Psychological Association. (2020). *Publication manual of the American
Psychological Association* (7.ª ed.). https://doi.org/10.1037/0000165-000

Bootstrap. (2025). *Bootstrap: The most popular HTML, CSS, and JS library in
the world* [Documentación en línea]. https://getbootstrap.com/

opencode. (2026). *opencode — AI assistant for the terminal* [Documentación en
línea]. https://opencode.ai