from django.db import models


class ConsultaIA(models.Model):
    pregunta = models.TextField('pregunta')
    respuesta = models.TextField('respuesta')
    fecha = models.DateTimeField('fecha de la consulta', auto_now_add=True)

    class Meta:
        verbose_name = 'consulta a la IA'
        verbose_name_plural = 'consultas a la IA'
        ordering = ['-fecha']

    def __str__(self):
        return self.pregunta[:60]