import json
from decimal import Decimal

import requests
from django.conf import settings

from inventario.models import Producto

SIN_INFORMACION = (
    'No encontré información suficiente en el inventario para responder esa pregunta.'
)

SYSTEM_PROMPT = (
    'Eres el asistente encargado de consultar el inventario de TechStore, '
    'una tienda de computadoras y periféricos de computadoras.\n\n'
    'Responde ÚNICAMENTE utilizando los datos incluidos en INVENTARIO y en DATOS CLAVE.\n'
    'No inventes productos, precios ni cantidades.\n'
    'DATOS CLAVE son cálculos realizados por el sistema y deben considerarse correctos.\n'
    'Si la información no está disponible o la pregunta no guarda relación con las '
    'computadoras o periféricos registrados, responde exactamente:\n'
    '"{sin_info}"\n\n'
    'DATOS CLAVE:\n{{datos_clave}}\n\n'
    'INVENTARIO:\n{{inventario}}\n\n'
    'PREGUNTA DEL USUARIO:\n{{pregunta}}'
).format(sin_info=SIN_INFORMACION)


class OllamaError(Exception):
    """Se lanza cuando no es posible comunicarse con Ollama."""


def inventario_json(solo_activos=True):
    productos = Producto.objects.filter(estado=True) if solo_activos else Producto.objects.all()
    datos = [
        {
            'codigo': p.codigo,
            'nombre': p.nombre,
            'categoria': p.categoria,
            'precio': float(p.precio),
            'cantidad_existente': p.cantidad_existente,
            'stock_minimo': p.stock_minimo,
        }
        for p in productos
    ]
    return json.dumps(datos, ensure_ascii=False, indent=2)


def datos_clave_json():
    """Hechos calculados por el sistema para que la IA responda con exactitud."""
    activos = Producto.objects.filter(estado=True)
    lista = list(activos)

    total = sum((p.precio * p.cantidad_existente for p in lista), Decimal('0'))
    agotados = [p.nombre for p in lista if p.agotado]
    stock_bajo = [f'{p.nombre} ({p.cantidad_existente} unidades)' for p in lista if p.stock_bajo]
    mas_caro = max(lista, key=lambda p: p.precio) if lista else None
    mas_barato = min(lista, key=lambda p: p.precio) if lista else None
    por_categoria = {}
    for p in lista:
        por_categoria.setdefault(p.categoria, []).append(p.nombre)

    return json.dumps({
        'cantidad_total_de_productos': len(lista),
        'producto_mas_caro': f'{mas_caro.nombre} (${mas_caro.precio})' if mas_caro else None,
        'producto_mas_barato': f'{mas_barato.nombre} (${mas_barato.precio})' if mas_barato else None,
        'valor_total_del_inventario': float(total),
        'productos_agotados': agotados,
        'productos_con_existencias_menores_o_iguales_al_stock_minimo': stock_bajo,
        'productos_por_categoria': por_categoria,
    }, ensure_ascii=False, indent=2)


def preguntar_a_ollama(pregunta):
    pregunta = (pregunta or '').strip()
    if not pregunta:
        raise OllamaError('La pregunta no puede estar vacía.')

    url = settings.OLLAMA_URL
    model = settings.OLLAMA_MODEL
    prompt = (
        SYSTEM_PROMPT
        .replace('{datos_clave}', datos_clave_json())
        .replace('{inventario}', inventario_json())
        .replace('{pregunta}', pregunta)
    )

    payload = {
        'model': model,
        'prompt': prompt,
        'stream': False,
        'options': {'temperature': 0},
    }

    try:
        respuesta = requests.post(
            url, data=json.dumps(payload), timeout=settings.OLLAMA_TIMEOUT,
            headers={'Content-Type': 'application/json'},
        )
        respuesta.raise_for_status()
    except requests.exceptions.ConnectionError as exc:
        raise OllamaError('No se pudo conectar con Ollama. Verifique que esté ejecutándose localmente.') from exc
    except requests.exceptions.Timeout as exc:
        raise OllamaError('Ollama tardó demasiado en responder. Intente de nuevo.') from exc
    except requests.exceptions.HTTPError as exc:
        raise OllamaError(f'Ollama devolvió un error: {exc.response.status_code}.') from exc

    try:
        data = respuesta.json()
    except ValueError as exc:
        raise OllamaError('Ollama devolvió una respuesta no válida.') from exc

    texto = data.get('response', '').strip()
    if not texto:
        raise OllamaError('Ollama no devolvió respuesta. Intente de nuevo.')
    return texto