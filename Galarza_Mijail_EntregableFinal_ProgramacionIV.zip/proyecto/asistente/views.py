from django.conf import settings
from django.contrib import messages
from django.shortcuts import redirect, render

from .forms import ChatForm
from .models import ConsultaIA
from .services import OllamaError, preguntar_a_ollama


def chat(request):
    form = ChatForm(request.POST or None)
    error = None
    consulta = None

    if request.method == 'POST' and form.is_valid():
        pregunta = form.cleaned_data['pregunta'].strip()
        try:
            respuesta = preguntar_a_ollama(pregunta)
            consulta = ConsultaIA.objects.create(pregunta=pregunta, respuesta=respuesta)
            form = ChatForm()
        except OllamaError as exc:
            error = str(exc)

    return render(request, 'asistente/chat.html', {
        'form': form,
        'error': error,
        'consulta': consulta,
        'modelo': settings.OLLAMA_MODEL,
        'historial': ConsultaIA.objects.all()[:5],
    })


def explicar(request):
    pregunta = request.GET.get('pregunta', '').strip()
    if not pregunta:
        messages.error(request, 'No se indicó ninguna pregunta para la IA.')
        return redirect('inventario:reportes')

    try:
        respuesta = preguntar_a_ollama(pregunta)
        consulta = ConsultaIA.objects.create(pregunta=pregunta, respuesta=respuesta)
    except OllamaError as exc:
        messages.error(request, str(exc))
        return redirect('inventario:reportes')

    return render(request, 'asistente/explicar.html', {
        'consulta': consulta,
        'modelo': settings.OLLAMA_MODEL,
    })


def historial(request):
    return render(request, 'asistente/historial.html', {
        'consultas': ConsultaIA.objects.all(),
    })