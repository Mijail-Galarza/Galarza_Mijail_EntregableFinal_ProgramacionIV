from django import forms


class ChatForm(forms.Form):
    pregunta = forms.CharField(
        label='Pregunta',
        widget=forms.Textarea(attrs={'rows': 3, 'placeholder': 'Ej: ¿Cuántos productos son computadoras?'}),
    )