from django.urls import path

from . import views

app_name = 'asistente'

urlpatterns = [
    path('chat/', views.chat, name='chat'),
    path('explicar/', views.explicar, name='explicar'),
    path('historial/', views.historial, name='historial'),
]