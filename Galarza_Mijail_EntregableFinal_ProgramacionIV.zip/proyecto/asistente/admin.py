from django.contrib import admin

from .models import ConsultaIA


@admin.register(ConsultaIA)
class ConsultaIAAdmin(admin.ModelAdmin):
    list_display = ('pregunta', 'fecha')
    search_fields = ('pregunta', 'respuesta')