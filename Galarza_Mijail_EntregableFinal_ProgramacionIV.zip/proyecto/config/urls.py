from django.contrib import admin
from django.urls import include, path
from django.views.generic import RedirectView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('productos/', include('inventario.urls')),
    path('ia/', include('asistente.urls')),
    path('', RedirectView.as_view(url='/productos/', permanent=False)),
]