from django import forms

from .models import Producto


class ProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = ['codigo', 'nombre', 'descripcion', 'categoria', 'precio', 'cantidad_existente', 'stock_minimo']
        widgets = {
            'descripcion': forms.Textarea(attrs={'rows': 3}),
            'precio': forms.NumberInput(attrs={'step': '0.01', 'min': '0'}),
            'cantidad_existente': forms.NumberInput(attrs={'min': '0'}),
            'stock_minimo': forms.NumberInput(attrs={'min': '0'}),
        }

    def clean_codigo(self):
        codigo = self.cleaned_data.get('codigo')
        if codigo:
            qs = Producto.objects.filter(codigo__iexact=codigo)
            if self.instance.pk:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise forms.ValidationError('Ya existe un producto con ese código.')
        return codigo

    def clean_precio(self):
        precio = self.cleaned_data.get('precio')
        if precio is not None and precio < 0:
            raise forms.ValidationError('El precio no puede ser negativo.')
        return precio

    def clean_cantidad_existente(self):
        cantidad = self.cleaned_data.get('cantidad_existente')
        if cantidad is not None and cantidad < 0:
            raise forms.ValidationError('La cantidad existente no puede ser negativa.')
        return cantidad

    def clean_stock_minimo(self):
        stock = self.cleaned_data.get('stock_minimo')
        if stock is not None and stock < 0:
            raise forms.ValidationError('El stock mínimo no puede ser negativo.')
        return stock


class AjusteStockForm(forms.Form):
    ACCIONES = [
        ('aumentar', 'Aumentar'),
        ('disminuir', 'Disminuir'),
    ]

    accion = forms.ChoiceField(label='Acción', choices=ACCIONES)
    cantidad = forms.IntegerField(label='Cantidad', min_value=1)

    def __init__(self, *args, **kwargs):
        self.producto = kwargs.pop('producto', None)
        super().__init__(*args, **kwargs)

    def clean(self):
        cleaned = super().clean()
        if not self.producto:
            raise forms.ValidationError('El producto no existe.')
        accion = cleaned.get('accion')
        cantidad = cleaned.get('cantidad')
        if accion == 'disminuir' and cantidad is not None:
            if cantidad > self.producto.cantidad_existente:
                raise forms.ValidationError(
                    'No se puede disminuir: la cantidad disponible quedaría negativa. '
                    f'Disponible actual: {self.producto.cantidad_existente}'
                )
        return cleaned