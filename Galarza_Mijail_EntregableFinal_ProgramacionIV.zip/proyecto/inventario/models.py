from django.db import models


class Categoria(models.TextChoices):
    COMPUTADORAS = 'Computadoras', 'Computadoras'
    PERIFERICOS = 'Periféricos', 'Periféricos'


class Producto(models.Model):
    codigo = models.CharField('código', max_length=20, unique=True)
    nombre = models.CharField('nombre', max_length=120)
    descripcion = models.TextField('descripción', blank=True)
    categoria = models.CharField(
        'categoría', max_length=30, choices=Categoria.choices, default=Categoria.COMPUTADORAS
    )
    precio = models.DecimalField('precio', max_digits=10, decimal_places=2)
    cantidad_existente = models.PositiveIntegerField('cantidad existente', default=0)
    stock_minimo = models.PositiveIntegerField('stock mínimo', default=0)
    estado = models.BooleanField('activo', default=True)
    fecha_registro = models.DateTimeField('fecha de registro', auto_now_add=True)

    @property
    def agotado(self):
        return self.cantidad_existente == 0

    @property
    def stock_bajo(self):
        return self.cantidad_existente <= self.stock_minimo

    @property
    def valor_total(self):
        return self.precio * self.cantidad_existente

    class Meta:
        verbose_name = 'producto'
        verbose_name_plural = 'productos'
        ordering = ['codigo']

    def __str__(self):
        return f'{self.codigo} - {self.nombre}'