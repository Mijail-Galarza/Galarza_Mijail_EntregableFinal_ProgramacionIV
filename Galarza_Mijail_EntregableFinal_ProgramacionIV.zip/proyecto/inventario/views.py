from decimal import Decimal

from django.contrib import messages
from django.db.models import Q, Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import AjusteStockForm, ProductoForm
from .models import Producto

CATEGORIAS = ['Computadoras', 'Periféricos']


def producto_lista(request):
    productos = Producto.objects.filter(estado=True)
    q = request.GET.get('q', '').strip()
    categoria = request.GET.get('categoria', '').strip()

    if q:
        productos = productos.filter(
            Q(codigo__icontains=q) | Q(nombre__icontains=q)
        )
    if categoria:
        productos = productos.filter(categoria=categoria)

    context = {
        'productos': productos,
        'q': q,
        'categorias': CATEGORIAS,
        'categoria_seleccionada': categoria,
    }
    return render(request, 'inventario/producto_lista.html', context)


def producto_crear(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Producto registrado correctamente.')
            return redirect('inventario:lista')
    else:
        form = ProductoForm()
    return render(request, 'inventario/producto_form.html', {'form': form, 'titulo': 'Registrar producto'})


def producto_editar(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == 'POST':
        form = ProductoForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            messages.success(request, 'Producto actualizado correctamente.')
            return redirect('inventario:lista')
    else:
        form = ProductoForm(instance=producto)
    return render(request, 'inventario/producto_form.html', {'form': form, 'titulo': f'Editar: {producto}'})


def producto_eliminar(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if producto.estado:
        if request.method == 'POST':
            producto.estado = False
            producto.save()
            messages.success(request, 'Producto desactivado correctamente.')
            return redirect('inventario:lista')
        return render(request, 'inventario/producto_confirmar_eliminar.html', {'producto': producto})
    messages.info(request, 'El producto ya estaba inactivo.')
    return redirect('inventario:lista')


def producto_restaurar(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if not producto.estado:
        producto.estado = True
        producto.save()
        messages.success(request, 'Producto reactivado correctamente.')
    return redirect('inventario:lista')


def producto_ajustar_stock(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if not producto.estado:
        messages.error(request, 'No se puede ajustar el stock de un producto inactivo.')
        return redirect('inventario:inactivos')

    form = AjusteStockForm(request.POST or None, producto=producto)
    if request.method == 'POST' and form.is_valid():
        accion = form.cleaned_data['accion']
        cantidad = form.cleaned_data['cantidad']
        if accion == 'aumentar':
            producto.cantidad_existente += cantidad
        else:
            producto.cantidad_existente -= cantidad
        producto.save(update_fields=['cantidad_existente'])
        messages.success(request, f'Stock actualizado. Disponible ahora: {producto.cantidad_existente} unidades.')
        return redirect('inventario:detalle', pk=producto.pk)

    return render(request, 'inventario/producto_ajustar_stock.html', {'form': form, 'producto': producto})


def producto_detalle(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    return render(request, 'inventario/producto_detalle.html', {'producto': producto})


def producto_inactivos(request):
    productos = Producto.objects.filter(estado=False)
    return render(request, 'inventario/producto_inactivos.html', {'productos': productos})


def productos_agotados(request):
    productos = Producto.objects.filter(estado=True, cantidad_existente=0)
    return render(request, 'inventario/producto_agotados.html', {
        'productos': productos,
        'pregunta_ia': '¿Qué productos están agotados en el inventario?',
    })


def productos_stock_bajo(request):
    productos = [p for p in Producto.objects.filter(estado=True) if p.stock_bajo]
    return render(request, 'inventario/producto_stock_bajo.html', {
        'productos': productos,
        'pregunta_ia': '¿Qué productos tienen pocas existencias?',
    })


def reportes_menu(request):
    return render(request, 'inventario/reportes_menu.html')


def reporte_mas_caro(request):
    productos = Producto.objects.filter(estado=True).order_by('-precio', 'nombre')
    producto = productos.first() if productos else None
    if producto:
        premieros = [p for p in productos if p.precio == producto.precio]
    else:
        premieros = []
    return render(request, 'inventario/reporte_generico.html', {
        'titulo': 'Producto más caro',
        'productos': premieros,
        'vacio': 'No hay productos registrados.',
        'pregunta_ia': '¿Cuál es el producto más caro del inventario?',
    })


def reporte_mas_barato(request):
    productos = Producto.objects.filter(estado=True).order_by('precio', 'nombre')
    producto = productos.first() if productos else None
    if producto:
        producto = [p for p in productos if p.precio == producto.precio]
    else:
        producto = []
    return render(request, 'inventario/reporte_generico.html', {
        'titulo': 'Producto más barato',
        'productos': producto,
        'vacio': 'No hay productos registrados.',
        'pregunta_ia': '¿Cuál es el producto más barato del inventario?',
    })


def reporte_valor_inventario(request):
    productos = Producto.objects.filter(estado=True)
    total = sum((p.precio * p.cantidad_existente for p in productos), Decimal('0'))
    return render(request, 'inventario/reporte_valor_inventario.html', {
        'total': total,
        'cantidad': len(productos),
        'pregunta_ia': '¿Cuál es el valor total del inventario?',
    })


def reporte_mayor_existencia(request):
    productos = Producto.objects.filter(estado=True).order_by('-cantidad_existente', 'nombre')
    productos = [p for p in productos if p.cantidad_existente > 0]
    return render(request, 'inventario/reporte_generico.html', {
        'titulo': 'Productos con mayor cantidad disponible',
        'productos': productos,
        'vacio': 'No hay productos con existencias registradas.',
        'pregunta_ia': '¿Qué productos tienen la mayor cantidad disponible?',
    })


def reporte_por_categoria(request):
    categoria = request.GET.get('categoria', '').strip()
    productos = []
    if categoria:
        productos = Producto.objects.filter(estado=True, categoria=categoria).order_by('codigo')
    return render(request, 'inventario/reporte_por_categoria.html', {
        'titulo': 'Productos por categoría',
        'categorias': CATEGORIAS,
        'categoria': categoria,
        'productos': productos,
        'pregunta_ia': f'¿Qué productos pertenecen a la categoría {categoria}?' if categoria else '',
    })