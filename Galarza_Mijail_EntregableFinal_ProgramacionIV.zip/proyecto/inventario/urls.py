from django.urls import path

from . import views

app_name = 'inventario'

urlpatterns = [
    path('', views.producto_lista, name='lista'),
    path('crear/', views.producto_crear, name='crear'),
    path('<int:pk>/', views.producto_detalle, name='detalle'),
    path('<int:pk>/editar/', views.producto_editar, name='editar'),
    path('<int:pk>/eliminar/', views.producto_eliminar, name='eliminar'),
    path('<int:pk>/restaurar/', views.producto_restaurar, name='restaurar'),
    path('<int:pk>/ajustar-stock/', views.producto_ajustar_stock, name='ajustar_stock'),
    path('inactivos/', views.producto_inactivos, name='inactivos'),
    path('stock/agotados/', views.productos_agotados, name='agotados'),
    path('stock/bajo/', views.productos_stock_bajo, name='stock_bajo'),
    path('reportes/', views.reportes_menu, name='reportes'),
    path('reportes/mas-caro/', views.reporte_mas_caro, name='reporte_mas_caro'),
    path('reportes/mas-barato/', views.reporte_mas_barato, name='reporte_mas_barato'),
    path('reportes/valor-inventario/', views.reporte_valor_inventario, name='reporte_valor_inventario'),
    path('reportes/mayor-existencia/', views.reporte_mayor_existencia, name='reporte_mayor_existencia'),
    path('reportes/por-categoria/', views.reporte_por_categoria, name='reporte_por_categoria'),
]