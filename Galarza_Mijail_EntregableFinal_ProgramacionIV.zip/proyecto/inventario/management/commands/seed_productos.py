from django.core.management.base import BaseCommand

from inventario.models import Producto

PRODUCTOS = [
    ('C001', 'Computadora portátil ASUS VivoBook 15', 'Laptop para uso general', 'Computadoras', 850.00, 5, 3),
    ('C002', 'Computadora de escritorio HP Pavilion', 'PC de escritorio con 16GB RAM', 'Computadoras', 720.00, 3, 2),
    ('C003', 'Computadora gamer Lenovo Legion', 'PC gamer con tarjeta RTX', 'Computadoras', 1350.00, 2, 1),
    ('C004', 'Computadora Apple MacBook Air', 'Laptop Apple con chip M2', 'Computadoras', 1100.00, 0, 2),
    ('P001', 'Teclado inalámbrico Logitech K380', 'Teclado Bluetooth compacto', 'Periféricos', 25.00, 2, 5),
    ('P002', 'Mouse gamer Razer DeathAdder', 'Mouse con sensor óptico', 'Periféricos', 45.00, 4, 4),
    ('P003', 'Monitor LG 24 pulgadas', 'Monitor Full HD 1920x1080', 'Periféricos', 130.00, 1, 3),
    ('P004', 'Impresora HP DeskJet', 'Impresora multifuncional', 'Periféricos', 95.00, 6, 2),
    ('P005', 'Audífonos con micrófono', 'Audífonos USB para videollamadas', 'Periféricos', 22.00, 0, 4),
    ('P006', 'Cámara web Logitech C920', 'Webcam Full HD USB', 'Periféricos', 60.00, 8, 2),
]


class Command(BaseCommand):
    help = 'Registra productos de ejemplo de la tienda de computadoras y periféricos.'

    def handle(self, *args, **options):
        creados = 0
        for codigo, nombre, descripcion, categoria, precio, cantidad, stock in PRODUCTOS:
            if not Producto.objects.filter(codigo=codigo).exists():
                Producto.objects.create(
                    codigo=codigo,
                    nombre=nombre,
                    descripcion=descripcion,
                    categoria=categoria,
                    precio=precio,
                    cantidad_existente=cantidad,
                    stock_minimo=stock,
                )
                creados += 1
        self.stdout.write(self.style.SUCCESS(f'Productos de ejemplo listos. Creados: {creados} de {len(PRODUCTOS)}.'))