# Requerimiento base del Entreagable Final Programación 4

## Sistema ejemplo de aplicación web de productos con CRUD e inteligencia artificial local mediante Ollama

### 1. Descripción general

Desarrollar una aplicación web utilizando Django que permita administrar un inventario básico de productos mediante operaciones CRUD y realizar consultas sobre la información registrada utilizando un modelo de inteligencia artificial local ejecutado con Ollama.

El sistema debe permitir consultar los productos mediante reportes predefinidos y mediante un chat, enviando a Ollama únicamente los datos necesarios del inventario para que genere una respuesta en lenguaje natural.

## 2. Objetivo general

Implementar una aplicación Django que integre:

- Registro de productos.
- Consulta, actualización y eliminación de productos.
- Control de cantidades existentes.
- Menú de reportes basado en los datos del inventario.
- Chat con inteligencia artificial local mediante Ollama.
- Generación de respuestas relacionadas exclusivamente con los productos registrados.

## 3. Alcance del sistema

El sistema estará compuesto por dos módulos principales:

### Módulo de productos

Permitirá administrar los datos del inventario mediante un CRUD.

### Módulo de inteligencia artificial

Permitirá consultar la información de los productos mediante:

- Reportes predefinidos.
- Preguntas escritas en un chat.
- Respuestas generadas por Ollama a partir de los datos registrados.

El proyecto no requiere implementar ventas, compras, usuarios avanzados, facturación ni conexión con servicios de inteligencia artificial en la nube.

# 4. Requerimientos funcionales

## RF-01. Registro de productos

El sistema debe permitir registrar productos con los siguientes datos:

- Código.
- Nombre.
- Descripción.
- Categoría.
- Precio.
- Cantidad existente.
- Stock mínimo.
- Estado del producto.
- Fecha de registro.

El código del producto debe ser único y los campos obligatorios deben validarse antes de guardar la información.

## RF-02. Consulta de productos

El sistema debe mostrar una lista de los productos registrados con:

- Código.
- Nombre.
- Categoría.
- Precio.
- Cantidad disponible.
- Estado.

Debe permitir buscar productos por:

- Código.
- Nombre.
- Categoría.

## RF-03. Actualización de productos

El usuario debe poder modificar la información de un producto existente.

El sistema debe validar que:

- El producto exista.
- El código no se repita con otro producto.
- El precio no sea negativo.
- La cantidad existente no sea negativa.

## RF-04. Eliminación de productos

El sistema debe permitir eliminar productos registrados.

Como alternativa, puede implementarse una eliminación lógica cambiando el estado del producto a “inactivo”. Esta opción es recomendable para conservar el historial de información.

## RF-05. Control de existencia

El sistema debe permitir:

- Registrar la cantidad existente de cada producto.
- Aumentar la cantidad disponible.
- Disminuir la cantidad disponible.
- Consultar productos agotados.
- Consultar productos con existencias menores o iguales al stock mínimo.
- Impedir que la cantidad disponible sea negativa.

## RF-06. Reportes predefinidos

El sistema debe incluir un menú de reportes con, como mínimo, las siguientes opciones:

1. Listar todos los productos.
2. Mostrar el producto más caro.
3. Mostrar el producto más barato.
4. Mostrar productos con pocas existencias.
5. Mostrar productos agotados.
6. Mostrar productos por categoría.
7. Mostrar el valor total del inventario.
8. Mostrar los productos con mayor cantidad disponible.

Los datos obtenidos por cada reporte deben poder presentarse directamente al usuario o enviarse a Ollama para generar una explicación en lenguaje natural.

### Ejemplo de resultado

Consulta:

> Productos con pocas existencias.

Respuesta generada:

> Se encontraron tres productos con existencias iguales o inferiores al stock mínimo: teclado, monitor y memoria RAM.

## RF-07. Chat con inteligencia artificial

El sistema debe incluir un formulario de chat que permita al usuario escribir preguntas relacionadas con los productos registrados.

Ejemplos de preguntas:

- ¿Qué productos son computadoras?
- ¿Cuál es el producto más barato?
- ¿Cuál es el producto más caro?
- ¿Qué productos tienen pocas existencias?
- ¿Cuántos productos pertenecen a la categoría periféricos?
- ¿Qué productos están agotados?
- ¿Cuál es el valor total del inventario?
- ¿Qué productos tienen un precio mayor a 500?
- Muéstrame los productos cuya existencia sea menor a 10.

El sistema debe enviar la pregunta y los datos necesarios del inventario al modelo local de Ollama.

## RF-08. Integración con Ollama

La aplicación debe comunicarse con Ollama mediante una conexión local.

El flujo esperado es:

1. El usuario escribe una pregunta.
2. Django recibe la consulta.
3. Django obtiene los productos registrados en la base de datos.
4. Django transforma los datos en un formato estructurado.
5. Django construye un contexto para la inteligencia artificial.
6. Django envía la consulta a Ollama.
7. Ollama procesa la información.
8. Django muestra la respuesta al usuario.

La aplicación debe utilizar un modelo instalado localmente en Ollama, por ejemplo:

```text
qwen2.5:1.5b
```

El modelo puede cambiarse mediante una variable de configuración.

## RF-09. Restricción de respuestas de la IA

La inteligencia artificial debe responder únicamente utilizando la información suministrada por el sistema.

Si la pregunta no está relacionada con los productos o si no existen datos suficientes, debe responder, por ejemplo:

> No encontré información suficiente en el inventario para responder esa pregunta.

La IA no debe inventar productos, precios o cantidades.

## RF-10. Historial de consultas

El sistema puede almacenar opcionalmente:

- Pregunta realizada.
- Respuesta generada.
- Fecha y hora.
- Usuario que realizó la consulta, si existe autenticación.

Este historial puede utilizarse para demostrar el funcionamiento de la integración con Ollama.

# 5. Modelo de datos

## Entidad Producto

| Campo              | Tipo         | Descripción               |
| ------------------ | ------------ | ------------------------- |
| id                 | Entero       | Identificador automático  |
| codigo             | Texto        | Código único del producto |
| nombre             | Texto        | Nombre del producto       |
| descripcion        | Texto        | Descripción general       |
| categoria          | Texto        | Categoría del producto    |
| precio             | Decimal      | Precio del producto       |
| cantidad_existente | Entero       | Cantidad disponible       |
| stock_minimo       | Entero       | Nivel mínimo permitido    |
| estado             | Booleano     | Activo o inactivo         |
| fecha_registro     | Fecha y hora | Fecha de creación         |

## Entidad ConsultaIA, opcional

| Campo     | Tipo         | Descripción                     |
| --------- | ------------ | ------------------------------- |
| id        | Entero       | Identificador de la consulta    |
| pregunta  | Texto        | Pregunta escrita por el usuario |
| respuesta | Texto        | Respuesta de Ollama             |
| fecha     | Fecha y hora | Fecha de la consulta            |

#` `6. Requerimientos no funcionales

- La aplicación debe desarrollarse con Django.
- La base de datos puede ser SQLite para desarrollo.
- Debe utilizarse Ollama ejecutándose localmente.
- La comunicación con Ollama debe realizarse desde el backend de Django.
- La interfaz debe ser clara y fácil de utilizar.
- Los formularios deben validar los datos antes de guardarlos.
- El sistema debe mostrar mensajes de éxito o error.
- La aplicación debe responder correctamente cuando Ollama no esté disponible.
- Las claves, URLs y nombres de modelos deben configurarse mediante variables de entorno o archivos de configuración.
- El código debe organizarse en aplicaciones, vistas, modelos, formularios y plantillas.
- Deben incluirse instrucciones para instalar y ejecutar el proyecto.

# 7. Arquitectura propuesta

```text
Usuario
   │
   ▼
Interfaz web Django
   │
   ├── CRUD de productos
   │       │
   │       ▼
   │   Base de datos
   │
   └── Consultas de IA
           │
           ▼
      Backend Django
           │
           ▼
          Ollama
           │
           ▼
       Modelo local
```

La comunicación con Ollama puede realizarse mediante su API local:

```text
http://localhost:11434
```

Ejemplo conceptual de configuración:

```python
OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.2"
```

---

# 8. Ejemplo de contexto enviado a Ollama

Django puede enviar los productos en formato JSON:

```json
[
  {
    "codigo": "P001",
    "nombre": "Computadora portátil",
    "categoria": "Computadoras",
    "precio": 850.00,
    "cantidad_existente": 5,
    "stock_minimo": 3
  },
  {
    "codigo": "P002",
    "nombre": "Teclado inalámbrico",
    "categoria": "Periféricos",
    "precio": 25.00,
    "cantidad_existente": 2,
    "stock_minimo": 5
  }
]
```

El prompt podría construirse así:

```text
Eres un asistente encargado de consultar un inventario.

Responde únicamente utilizando los datos incluidos en INVENTARIO.
No inventes productos, precios ni cantidades.
Si la información no está disponible, indícalo claramente.

INVENTARIO:
{productos}

PREGUNTA DEL USUARIO:
{pregunta}
```

# 9. Criterios de aceptación

El proyecto se considerará funcional cuando:

- Se pueda crear un producto.
- Se pueda consultar la lista de productos.
- Se pueda editar un producto.
- Se pueda eliminar o desactivar un producto.
- Se valide que el código sea único.
- No se permitan precios ni cantidades negativas.
- Se puedan consultar productos por nombre o categoría.
- Se pueda identificar el producto más caro.
- Se pueda identificar el producto más barato.
- Se puedan consultar productos con pocas existencias.
- Se pueda consultar el valor total del inventario.
- El usuario pueda realizar preguntas desde un chat.
- Django pueda enviar los datos a Ollama.
- Ollama pueda generar respuestas usando los productos registrados.
- El sistema informe adecuadamente cuando Ollama no esté disponible.
- La IA no responda inventando información que no exista en la base de datos.
- El proyecto incluya instrucciones de instalación y ejecución.



# 10. Entregables

El estudiante debe entregar:

1. Código fuente del proyecto Django.
2. Aplicación CRUD de productos.
3. Integración funcional con Ollama.
4. Menú de reportes.
5. Chat para consultas sobre el inventario.
6. Modelo de base de datos.
7. Archivo `requirements.txt`.
8. Archivo `.env.example`, si se utilizan variables de entorno.
9. Documento con instrucciones de instalación.
10. Evidencias de funcionamiento:
    - Registro de productos.
    - Edición y eliminación.
    - Reportes.
    - Consulta mediante chat.
    - Respuesta generada por Ollama.
11. Video o presentación de demostración, si es solicitado por la materia.

## Resultado esperado

Al finalizar, el usuario podrá registrar productos en Django y realizar consultas como:

> ¿Cuál es el producto más caro?

> ¿Qué productos tienen menos de cinco unidades?

> ¿Qué productos pertenecen a la categoría computadoras?

> ¿Cuál es el valor total del inventario?

El sistema responderá utilizando los datos reales almacenados en la base de datos y procesados mediante un modelo de inteligencia artificial local ejecutado con Ollama.
